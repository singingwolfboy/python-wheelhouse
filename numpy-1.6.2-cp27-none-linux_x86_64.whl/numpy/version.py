
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.6.2'
version = '1.6.2'
full_version = '1.6.2'
git_revision = 'ca07bce202ae26b6f0a73870eb2ef0b88e0210c5'
release = True

if not release:
    version = full_version
